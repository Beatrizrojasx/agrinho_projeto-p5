let campo;
let cidade;
let conexao;
let numPontosCampo = 50;
let numPontosCidade = 50;
let pontosCampo = [];
let pontosCidade = [];

function setup() {
  createCanvas(600, 400);
  campo = color(100, 200, 100); // Verde para o campo
  cidade = color(150, 150, 150); // Cinza para a cidade
  conexao = color(200, 100, 50); // Laranja para a conexão

  // Inicializa os pontos do campo
  for (let i = 0; i < numPontosCampo; i++) {
    pontosCampo.push(createVector(random(width * 0.2), random(height * 0.2, height * 0.8)));
  }

  // Inicializa os pontos da cidade
  for (let i = 0; i < numPontosCidade; i++) {
    pontosCidade.push(createVector(random(width * 0.8, width), random(height * 0.2, height * 0.8)));
  }
}

function draw() {
  background(220);

  // Desenha a área do campo
  fill(campo);
  rect(0, 0, width * 0.3, height);

  // Desenha a área da cidade
  fill(cidade);
  rect(width * 0.7, 0, width * 0.3, height);

  // Desenha os pontos do campo
  fill(255);
  noStroke();
  for (let p of pontosCampo) {
    ellipse(p.x, p.y, 8, 8);
  }

  // Desenha os pontos da cidade
  fill(0);
  for (let p of pontosCidade) {
    ellipse(p.x, p.y, 8, 8);
  }

  // Desenha as linhas de conexão
  stroke(conexao);
  for (let i = 0; i < min(pontosCampo.length, pontosCidade.length); i++) {
    line(pontosCampo[i].x, pontosCampo[i].y, pontosCidade[i].x, pontosCidade[i].y);
  }

  // Texto informativo
  fill(0);
  textSize(16);
  textAlign(LEFT, CENTER);
  text("Campo", 20, height / 2);
  textAlign(RIGHT, CENTER);
  text("Cidade", width - 20, height / 2);
  textAlign(CENTER, BOTTOM);
  text("Conexão Campo-Cidade", width / 2, height - 10);
}